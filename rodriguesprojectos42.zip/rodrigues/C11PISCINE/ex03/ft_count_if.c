/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_count_if.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rsonhi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/12 07:43:06 by rsonhi            #+#    #+#             */
/*   Updated: 2024/12/12 07:43:08 by rsonhi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_count_if(char **tab, int length, int (*f)(char *))
{
	int	sum;
	int	cur;

	cur = 0;
	sum = 0;
	while (cur < length)
	{
		if ((*f)(tab[cur]) != 0)
			sum++;
		cur++;
	}
	return (sum);
}
