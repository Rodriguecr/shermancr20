/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rsonhi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/12 07:42:31 by rsonhi            #+#    #+#             */
/*   Updated: 2024/12/12 07:42:33 by rsonhi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_map(int *tab, int length, int (*f)(int))
{
	int	cur;
	int	*result_tab;

	cur = 0;
	result_tab = (int *)malloc(sizeof(int) * length);
	while (cur < length)
	{
		result_tab[cur] = (*f)(tab[cur]);
		cur++;
	}
	return (result_tab);
}
