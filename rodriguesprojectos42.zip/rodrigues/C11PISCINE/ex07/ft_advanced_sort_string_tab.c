/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_advanced_sort_string_tab.c                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rsonhi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/12 07:44:25 by rsonhi            #+#    #+#             */
/*   Updated: 2024/12/12 07:44:27 by rsonhi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_advanced_sort_string_tab(char **tab, int (*cmp)(char *, char *))
{
	int		cur;
	int		cur2;
	char	*temp;

	cur = 0;
	while (tab[cur] != 0)
	{
		cur2 = cur;
		while (tab[cur2] != 0)
		{
			if (cmp(tab[cur], tab[cur2]) > 0)
			{
				temp = tab[cur];
				tab[cur] = tab[cur2];
				tab[cur2] = temp;
			}
			cur2++;
		}
		cur++;
	}	
}
