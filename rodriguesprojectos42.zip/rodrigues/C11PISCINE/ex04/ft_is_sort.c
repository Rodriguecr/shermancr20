/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rsonhi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/12 07:43:20 by rsonhi            #+#    #+#             */
/*   Updated: 2024/12/12 07:43:25 by rsonhi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	is_asc(int *tab, int length, int (*f)(int, int))
{
	int	cur;

	cur = 0;
	while (cur < length - 1)
	{
		if ((*f)(tab[cur], tab[cur + 1]) > 0)
			return (0);
		cur++;
	}
	return (1);
}

int	is_desc(int *tab, int length, int (*f)(int, int))
{
	int	cur;

	cur = 0;
	while (cur < length - 1)
	{
		if ((*f)(tab[cur], tab[cur + 1]) < 0)
			return (0);
		cur++;
	}
	return (1);
}

int	ft_is_sort(int *tab, int length, int (*f)(int, int))
{
	if (is_desc(tab, length, f) == 1 || is_asc(tab, length, f) == 1)
		return (1);
	else
		return (0);
}
