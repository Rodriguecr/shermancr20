# 42-BSQ
Will you find the biggest square ?

[![norminette](https://github.com/Alexdelia/42-BSQ/actions/workflows/norminette.yml/badge.svg)](https://github.com/Alexdelia/42-BSQ/actions/workflows/norminette.yml) [![Codacy Badge](https://app.codacy.com/project/badge/Grade/a533629f42af4f1f94623f9a2ab1d1d6)](https://www.codacy.com/gh/Alexdelia/42-BSQ/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=Alexdelia/42-BSQ&amp;utm_campaign=Badge_Grade)

## Map generator
Perl script `gen_map.pl`:
```sh
perl gen_map.pl [LEN_LINES] [NBR_LINES] [DENSITY]
```
