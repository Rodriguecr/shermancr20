/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rsonhi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/29 10:53:49 by rsonhi            #+#    #+#             */
/*   Updated: 2024/11/30 11:45:21 by rsonhi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	cur;
	int	num;

	if (nb < 0)
		return (0);
	if (nb == 0)
		return (1);
	cur = 0;
	num = 1;
	while (cur++ < nb)
		num *= cur;
	return (num);
}
