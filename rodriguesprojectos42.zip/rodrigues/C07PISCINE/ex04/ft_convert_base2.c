/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rsonhi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/09 13:51:36 by rsonhi            #+#    #+#             */
/*   Updated: 2024/12/09 13:51:39 by rsonhi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	checkbase(char *base)
{
	int	i;
	int	j;

	i = 0;
	while (base[i])
	{
		if (base[i] == '+' || base[i] == '-')
			return (1);
		j = i + 1;
		while (base[j])
		{
			if (base[i] == base[j])
				return (1);
			j++;
		}
		i++;
	}
	if (i < 2)
		return (1);
	return (0);
}

void	ft_create_nbr_base(int nbr, char *base, char *ptr, int *index)
{
	long int	n;
	int			blen;

	n = nbr;
	blen = ft_strlen(base);
	if (n < 0)
	{
		ptr[*index] = '-';
		*index = *index + 1;
		n = -n;
	}
	if (n < blen)
	{
		ptr[*index] = base[n];
		*index = *index + 1;
	}
	else
	{
		ft_create_nbr_base(n / blen, base, ptr, index);
		ptr[*index] = base[n % blen];
		*index = *index + 1;
	}
}
