/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rsonhi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/09 13:53:09 by rsonhi            #+#    #+#             */
/*   Updated: 2024/12/09 13:53:12 by rsonhi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	ft_is_sep(char *sep, char c)
{
	int	i;

	i = 0;
	while (sep[i] != '\0')
	{
		if (sep[i] == c)
			return (1);
		i++;
	}
	return (0);
}

void	ft_modif(int *ijkl, char **array, char *str, char *charset)
{
	int		count;
	char	*s;

	count = 0;
	while (str[ijkl[0]])
	{
		while (ft_is_sep(charset, str[ijkl[0]]) != 1 && str[ijkl[0]])
		{
			ijkl[0]++;
			count++;
		}
		ijkl[2] = 0;
		s = malloc((ft_strlen(str) + 1) * sizeof(char));
		while (count > 0)
		{
			s[ijkl[2]++] = str[ijkl[1]++];
			count--;
		}
		s[ijkl[2]] = '\0';
		while (ft_is_sep(charset, str[ijkl[0]]) == 1)
			ijkl[0]++;
		if (s[0] != '\0')
			array[ijkl[3]++] = s;
		ijkl[1] = ijkl[0];
	}
}

char	**ft_split(char *str, char *charset)
{
	int		ijkl[4];
	char	**array;

	ijkl[0] = 0;
	ijkl[1] = 0;
	ijkl[2] = 0;
	ijkl[3] = 0;
	array = malloc((ft_strlen(str) + 1) * sizeof(char *));
	ft_modif(ijkl, array, str, charset);
	array[ijkl[3]] = 0;
	return (array);
}
