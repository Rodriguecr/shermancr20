/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rsonhi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/09 13:51:03 by rsonhi            #+#    #+#             */
/*   Updated: 2024/12/09 13:51:06 by rsonhi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	len;

	len = 0;
	while (*str)
	{
		len++;
		str++;
	}
	return (len);
}

char	*ft_strcpy(char *dest, char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest + i);
}

int	return_length(int size, char **strs, int size_sep)
{
	int	i;
	int	len;

	i = 0;
	len = 0;
	while (i < size)
	{
		len += ft_strlen(strs[i]);
		if (i + 1 < size)
			len += size_sep;
		i++;
	}
	return (len);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		i;
	char	*res;
	int		len;

	if (size == 0)
	{
		res = (char *)malloc(1);
		if (res)
			*res = '\0';
		return (res);
	}
	len = return_length(size, strs, ft_strlen(sep));
	res = (char *)malloc(len + 1);
	if (res == NULL)
		return (NULL);
	res[0] = '\0';
	i = 0;
	while (i < size)
	{
		ft_strcpy(res + ft_strlen(res), strs[i]);
		if (i + 1 < size)
			ft_strcpy(res + ft_strlen(res), sep);
		i++;
	}
	return (res);
}
