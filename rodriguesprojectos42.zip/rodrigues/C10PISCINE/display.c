/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rsonhi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/12 07:22:39 by rsonhi            #+#    #+#             */
/*   Updated: 2024/12/12 08:02:54 by rsonhi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>

int	ft_display(char *file)
{
	int	r;
        int	f;
        char	a;

        f = open(file, 0);
        if (f == -1)
                return (0);
        while (1)
	{
		r = read(f, &a, 1);
		if (r == -1)
		break ;
	}
	return (close(f));
}

int	main(int argc, char **argv)
{
	if (argc == 1)
		write(2, "File name missing.\n", 19);
	else if (argc > 2)
		write(2, "Too many arguments.\n", 20);
	else
	{
		if (!ft_display(argv[1]))
			write(2, "Cannot read file.\n", 16);
	}
	return (0);
}
