#!/bin/sh
git log --format="%H" -n 5

