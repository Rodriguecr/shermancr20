/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rsonhi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/09 18:23:32 by rsonhi            #+#    #+#             */
/*   Updated: 2024/12/09 18:25:06 by rsonhi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	**ft_split(char *str, char *charset);

int	main(void)
{
	char	**result;
	int		cur;

	printf("Hello World    !! :\n");
	result = ft_split("Hello World    !!", " ");
	cur = -1;
	while (cur++, result[cur] != 0)
		printf("%d => %s\n", cur, result[cur]);
	printf("\naaaa bbbb..cccc .dddd!!eeee :\n");
	result = ft_split("aaaa bbbb..cccc .dddd!!eeee", " .!");
	cur = -1;
	while (cur++, result[cur] != 0)
		printf("%d => %s\n", cur, result[cur]);
}
