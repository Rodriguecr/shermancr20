find . | wc -l | xargs
