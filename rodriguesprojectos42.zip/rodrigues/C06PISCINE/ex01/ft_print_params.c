/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rsonhi <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/12/06 12:39:30 by rsonhi            #+#    #+#             */
/*   Updated: 2024/12/06 12:41:22 by rsonhi           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int argc, char **argv)
{
	int	cur;
	int	cur2;

	if (argc < 2)
		return (0);
	cur = 1;
	while (cur < argc)
	{
		cur2 = 0;
		while (argv[cur][cur2] != 0)
		{
			write(1, &argv[cur][cur2], 1);
			cur2++;
		}
		write(1, "\n", 1);
		cur++;
	}
}
