#/bin/sh
git log -5 --pretty=tformat:'%H'
