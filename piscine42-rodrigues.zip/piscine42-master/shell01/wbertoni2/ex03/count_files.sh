#/bin/sh
find . | wc -l | tr -d ' '
