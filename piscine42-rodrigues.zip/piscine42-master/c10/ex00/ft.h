#ifndef FT_H
# define FT_H

#include <fcntl.h>
#include <unistd.h>

void	ft_putstr(char *str);


#endif
