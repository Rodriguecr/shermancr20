#include <stdio.h>

int ft_sqrt(int nb);

int	main(void)
{
	printf("1: %i\n", ft_sqrt(1)); 
	printf("2: %i\n", ft_sqrt(2)); 
	printf("3: %i\n", ft_sqrt(3)); 
	printf("4: %i\n", ft_sqrt(4)); 
	printf("9: %i\n", ft_sqrt(9)); 
}
