# PISCINA 42
## Português
- Exercícios realizados por mim na piscina de novembro/2019 da Escola 42.
- Os exercícios Shell00 até o C06 foram analisados pela Moullinette.
- Nem todos os exercícios estão corretos. Utilize-os por sua conta e risco.
- A partir da lista C07 os exercícios foram realizados por mim sem qualquer verificação da Moullinette ou da Norminette. Utilize-os por sua conta e risco.

## English
- Exercises done by myself at 42 School  piscine november/2019.
- The exercises Shell00 until C06 were evaluated by Moullinette.
- Not all exercises are correct. Use ate your own risk.
- Starting from the list C07 the exercises were done by me without any evaluation from Moullinette or Norminette. Use at your own risk.
